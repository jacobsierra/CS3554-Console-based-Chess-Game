import position.Position;
import java.util.ArrayList;
import java.util.List;

public class Pawn extends Piece {
    public Pawn(String color, Position position) {
        super(color, position);
    }
    @Override
    public List<Position> possibleMoves(Piece[][] board) {
        List<Position> moves = new ArrayList<>();
        int direction = color.equals("white") ? -1 : 1;
        int row = position.row;
        int col = position.col;
        int newRow = row + direction;
        if (newRow >= 0 && newRow < 8 && board[newRow][col] == null) {
            moves.add(new Position(newRow, col));
        }
        return moves;
    }
    @Override
    public String toString() {
        return color.equals("white") ? "wp" : "bp";
    }
}
