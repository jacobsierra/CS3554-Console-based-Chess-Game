import position.Position;
import java.util.ArrayList;
import java.util.List;

public class Knight extends Piece {
    public Knight(String color, Position position) {
        super(color, position);
    }
    @Override
    public List<Position> possibleMoves(Piece[][] board) {
        List<Position> moves = new ArrayList<>();
        int[][] offsets = {
            {-2, -1}, {-2, 1}, {-1, -2}, {-1, 2},
            {1, -2}, {1, 2}, {2, -1}, {2, 1}
        };
        for (int[] offset : offsets) {
            int newRow = position.row + offset[0];
            int newCol = position.col + offset[1];
            if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                Piece target = board[newRow][newCol];
                if (target == null || !target.getColor().equals(color)) {
                    moves.add(new Position(newRow, newCol));
                }
            }
        }
        return moves;
    }
    @Override
    public String toString() {
        return color.equals("white") ? "wN" : "bN";
    }
}
