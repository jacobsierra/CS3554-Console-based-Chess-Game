import pieces.*;
import position.Position;

public class Board {
    private Piece[][] grid = new Piece[8][8];

    public Board() {
        initialize();
    }
    public void initialize() {
        for (int col = 0; col < 8; col++) {
            grid[6][col] = new Pawn("white", new Position(6, col));
        }
        for (int col = 0; col < 8; col++) {
            grid[1][col] = new Pawn("black", new Position(1, col));
        }
        grid[7][0] = new Rook("white", new Position(7, 0));
        grid[7][1] = new Knight("white", new Position(7, 1));
        grid[7][2] = new Bishop("white", new Position(7, 2));
        grid[7][3] = new Queen("white", new Position(7, 3));
        grid[7][4] = new King("white", new Position(7, 4));
        grid[7][5] = new Bishop("white", new Position(7, 5));
        grid[7][6] = new Knight("white", new Position(7, 6));
        grid[7][7] = new Rook("white", new Position(7, 7));

        grid[0][0] = new Rook("black", new Position(0, 0));
        grid[0][1] = new Knight("black", new Position(0, 1));
        grid[0][2] = new Bishop("black", new Position(0, 2));
        grid[0][3] = new Queen("black", new Position(0, 3));
        grid[0][4] = new King("black", new Position(0, 4));
        grid[0][5] = new Bishop("black", new Position(0, 5));
        grid[0][6] = new Knight("black", new Position(0, 6));
        grid[0][7] = new Rook("black", new Position(0, 7));
    }
    public Piece getPiece(Position position) {
        return grid[position.row][position.col];
    }
    public void movePiece(Position from, Position to) {
        Piece piece = getPiece(from);
        if (piece != null) {
            grid[to.row][to.col] = piece;
            grid[from.row][from.col] = null;
            piece.move(to);
        }
    }
    public void display() {
        System.out.println();
        for (int row = 0; row < 8; row++) {
            System.out.print(8 - row + " ");
            for (int col = 0; col < 8; col++) {
                Piece piece = grid[row][col];
                if (piece == null) {
                    System.out.print((row + col) % 2 == 0 ? "## " : "   ");
                } else {
                    System.out.print(piece + " ");
                }
            }
            System.out.println();
        }
        System.out.println("  A  B  C  D  E  F  G  H\n");
    }
    public Piece[][] getGrid() {
        return grid;
    }
}
