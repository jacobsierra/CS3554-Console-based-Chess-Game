import board.Board;
import pieces.Piece;
import position.Position;
import utilities.Utilities;
import java.util.Scanner;
import java.util.List;

public class Player {
    private final String color;

    public Player(String color) {
        this.color = color;
    }
    public String getColor() {
        return color;
    }
    public boolean makeMove(Board board, Scanner scanner) {
        System.out.print(color.substring(0, 1).toUpperCase() + color.substring(1) + " to move: ");
        String input = scanner.nextLine().trim().toUpperCase();
        String[] parts = input.split(" ");
        if (parts.length != 2 || !Utils.isValidNotation(parts[0]) || !Utils.isValidNotation(parts[1])) {
            System.out.println("Invalid input format. Please use format like E2 E4.");
            return false;
        }
        Position from = Utils.notationToPosition(parts[0]);
        Position to = Utils.notationToPosition(parts[1]);
        Piece piece = board.getPiece(from);
        if (piece == null) {
            System.out.println("No piece at " + parts[0]);
            return false;
        }
        if (!piece.getColor().equals(this.color)) {
            System.out.println("You can only move your own pieces.");
            return false;
        }
        List<Position> validMoves = piece.possibleMoves(board.getGrid());
        if (!validMoves.contains(to)) {
            System.out.println("Invalid move for that piece.");
            return false;
        }
        board.movePiece(from, to);
        return true;
    }
}
