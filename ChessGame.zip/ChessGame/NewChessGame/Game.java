import java.util.Scanner;

public class Game {
    private final Board board;
    private final Player whitePlayer;
    private final Player blackPlayer;
    private Player currentPlayer;
    private final Scanner scanner;

    public Game() {
        board = new Board();
        whitePlayer = new Player("white");
        blackPlayer = new Player("black");
        currentPlayer = whitePlayer;
        scanner = new Scanner(System.in);
    }
    public void play() {
        System.out.println("Welcome to Chess!");
        System.out.println("Enter moves in format: E2 E4\n");
        while (true) {
            board.display();
            boolean moved = currentPlayer.makeMove(board, scanner);
            if (moved) {
                switchTurn();
            }
        }
    }

    private void switchTurn() {
        currentPlayer = (currentPlayer == whitePlayer) ? blackPlayer : whitePlayer;
    }
    public static void main(String[] args) {
        Game game = new Game();
        game.play();
    }
}
