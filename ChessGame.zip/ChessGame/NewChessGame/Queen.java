import java.util.ArrayList;
import java.util.List;

public class Queen extends Piece {
    public Queen(String color, Position position) {
        super(color, position);
    }
    @Override
    public List<Position> possibleMoves(Piece[][] board) {
        List<Position> moves = new ArrayList<>();
        int[][] directions = {
            {-1, 0}, {1, 0}, {0, -1}, {0, 1},
            {-1, -1}, {-1, 1}, {1, -1}, {1, 1}
        };
        for (int[] dir : directions) {
            int row = position.row;
            int col = position.col;
            while (true) {
                row += dir[0];
                col += dir[1];
                if (row < 0 || row >= 8 || col < 0 || col >= 8) {
                    break;
                }
                if (board[row][col] == null) {
                    moves.add(new Position(row, col));
                } 
                else {
                    if (!board[row][col].getColor().equals(color)) {
                        moves.add(new Position(row, col));
                    }
                    break;
                }
            }
        }
        return moves;
    }
    @Override
    public String toString() {
        return color.equals("white") ? "wQ" : "bQ";
    }
}
