public class Utilities {
    public static Position notationToPosition(String notation) {
        if (!isValidNotation(notation)) return null;
        char file = Character.toUpperCase(notation.charAt(0));
        int rank = Character.getNumericValue(notation.charAt(1));
        int col = file - 'A'; 
        int row = 8 - rank;
        return new Position(row, col);
    }
    public static String positionToNotation(Position position) {
        char file = (char) ('A' + position.col);
        int rank = 8 - position.row;
        return "" + file + rank;
    }
    public static boolean isValidNotation(String notation) {
        if (notation == null || notation.length() != 2) return false;
        char file = Character.toUpperCase(notation.charAt(0));
        char rank = notation.charAt(1);
        return file >= 'A' && file <= 'H' && rank >= '1' && rank <= '8';
    }
}
