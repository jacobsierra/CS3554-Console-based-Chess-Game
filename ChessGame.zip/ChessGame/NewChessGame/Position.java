public class Position {
    public int row;
    public int col;
    public Position(int row, int col) {
        this.row = row;
        this.col = col;
    }
    public static Position fromString(String pos) {
        int col = pos.charAt(0) - 'A';
        int row = 8 - Character.getNumericValue(pos.charAt(1));
        return new Position(row, col);
    }
    public String toString() {
        return "" + (char) ('A' + col) + (8 - row);
    }
}
